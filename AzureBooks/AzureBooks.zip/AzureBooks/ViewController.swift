//
//  ViewController.swift
//  AzureBooks
//
//  Created by Shubham Vaishnav on 31/07/20.
//  Copyright © 2020 Capgemini. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

